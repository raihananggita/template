
@extends('template')
@section('content')
<div class="content">
        
        <!-- DBD -->
        <div class="row">
          <div class="col-md-12">
            <div class="card ">
              <div class="card-header ">
                <h5 class="card-title">Grafik Penderita DBD</h5>
                <p class="card-category">Tahun 2015-2020</p>
              </div>
              <div class="card-body ">
                <canvas id=chartHours width="400" height="100"></canvas>
              </div>
              <div class="card-footer ">
                <hr>
                <div class="stats">
                  <i class="fa fa-history"></i> 2015-2020 
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- DBD -->
        
        <!-- BMKG -->
        <div class="row">
          <div class="col-md-12">
            <div class="card ">
              <div class="card-header ">
                <h5 class="card-title">Grafik BMKG</h5>
                <p class="card-category">Tahun 2015-2020</p>
              </div>
              <div class="card-body ">
                <canvas id=chartHours width="400" height="100"></canvas>
              </div>
              <div class="card-footer ">
                <hr>
                <div class="stats">
                  <i class="fa fa-history"></i> 
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- BMKG -->

        <div class="row">
          <div class="col-md-4">
            <div class="card ">
              
              
              
            </div>
          </div>
          <div class="col-md-12">
            <div class="card card-chart">
              <div class="card-header">
                <h5 class="card-title">ANALISIS PENGARUH IKLIM TERHADAP INFEKSI DEMAM BERDARAH</h5>
                <p class="card-category">KECAMATAN TANJUNG PRIOK, KOTA ADMINISTRASI JAKARTA UTARA</p>
              </div>
              <div class="card-body">
                <canvas id="speedChart" width="100" height="0.1"></canvas>
                <p> Grafik diatas merupakan grafik penderita DBD dan BMKG Pada Tahun 2015 - 2020, Grafik diatas nantinya akan dianalisis menggukanan time series & digunakan untuk memprediksi jumlah kasus DBD dengan pengaruh iklim di Kecamatan Tanjung Priok Jakarta Utara. Dengan menggunakan 3 Metode yaitu Ridge Regression, ELM, GSTAR  maka metode tersebut akan dibandingkan keakuratannya.
              </div>
              <div class="card-footer">
                
                <hr />
                <div class="card-stats">
                  <i class="fa fa-check"></i> Data information certified
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
@endsection